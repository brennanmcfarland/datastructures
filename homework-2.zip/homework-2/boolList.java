public interface boolList{
  public int size();
  public void insert(int i, boolean value);
  public void remove(int i);
  boolean lookup(int i);
  boolean negateAll();
}
